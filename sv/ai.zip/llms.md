# regionstockholm.core.template#2.3.0: Region Stockholm FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Informationsunderlag](information-basis.md)
* [Mappning till profiler](mappings.md)
* [Om](about.md)
* [Felhantering](error-handling.md)
* [Versionshistorik](version-history.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Testning och validering](testing.md)
* [Sammanfattning av artefakter](artifacts.md)
* [CapabilityStatement](capabilitystatement.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Användningsfall](use-cases.md)
* [Nedladdningar](downloads.md)
* [Inledning](introduction.md)
* [Förväntade svar](expected-responses.md)
* [Säkerhet och behörighet](security.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Region Stockholm FHIR Implementation Guide Template](ImplementationGuide-regionstockholm.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
