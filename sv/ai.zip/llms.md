# regionstockholm.core.template#2.3.0: Region Stockholm FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Testning och validering](testing.md)
* [Förväntade svar](expected-responses.md)
* [CapabilityStatement](capabilitystatement.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Användningsfall](use-cases.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Versionshistorik](version-history.md)
* [Inledning](introduction.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Säkerhet och behörighet](security.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Region Stockholm FHIR Implementation Guide Template](ImplementationGuide-regionstockholm.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
