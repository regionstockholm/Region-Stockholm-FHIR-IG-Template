# Förväntade svar - Region Stockholm FHIR Implementation Guide Template v2.3.0

## Förväntade svar

**Beskriv vilka svar en klient ska förvänta sig för respektive interaktion (se [REST-interaktioner och sökparametrar](rest-interactions.md)), inklusive statuskoder vid lyckat anrop, paginering vid sökningar, och eventuella `Bundle`-typer som används.**

